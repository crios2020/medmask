package com.diycovid19mask.medmask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Pantalla11_solicitante extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla11_solicitante);
    }
}